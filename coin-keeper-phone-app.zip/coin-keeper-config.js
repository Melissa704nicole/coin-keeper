// Coin Keeper private sync setup.
// This file is safe to publish with the app when it contains only your project URL
// and the Supabase publishable key. Never place a secret or service_role key here.
window.COIN_KEEPER_CONFIG = {
  supabaseUrl: '',
  supabasePublishableKey: ''
};
